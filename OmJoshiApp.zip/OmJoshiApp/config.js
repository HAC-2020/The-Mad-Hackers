export default firebasekeys = {
  apiKey: "AIzaSyBRinKG0wa8nULNhGsCZg0vkEMxqmKEtMo",
  authDomain: "omjoshiapp.firebaseapp.com",
  databaseURL: "https://omjoshiapp.firebaseio.com",
  projectId: "omjoshiapp",
  storageBucket: "omjoshiapp.appspot.com",
  messagingSenderId: "688695948267",
  appId: "1:688695948267:web:a1f0ef092668e112d91fae",
  measurementId: "G-YKWXX4J7R1"
}